import streamlit as st
import requests
from docx import Document
from docx.shared import Inches as DocxInches, Pt as DocxPt, RGBColor as DocxRGBColor
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from fpdf import FPDF # Pastikan ini adalah fpdf2: pip install fpdf2
import pandas as pd
from datetime import datetime
import os
import json
from pptx import Presentation
from pptx.util import Inches as PptxInches, Pt as PptxPt
from pptx.dml.color import RGBColor as PptxRGBColor
import time
from PIL import Image
import pytesseract # Anda mungkin perlu memasang Tesseract OCR: https://github.com/tesseract-ocr/tesseract
import fitz  # PyMuPDF untuk PDF: pip install PyMuPDF

# --- KONFIGURASI ---
HISTORY_DIR = "chat_sessions"
UPLOAD_DIR = "uploaded_files" # Direktori untuk fail yang dimuat naik
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
DEFAULT_OLLAMA_MODEL = os.getenv("DEFAULT_OLLAMA_MODEL", "llama3") # Model lalai

# Konfigurasi untuk ciri dari chatbot2
LOGO_PATH = os.getenv("ikm_logo", "ikm_logo.png") # Letakkan logo anda di sini dan namakannya ikm_logo.png atau set pembolehubah persekitaran
WATERMARK_TEXT = os.getenv("CHATBOT_WATERMARK_TEXT", "IKM Besut")
# Pastikan Tesseract OCR dipasang dan dikonfigurasi dalam PATH sistem anda, atau setkan laluan tesseract_cmd
# Contoh: pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

os.makedirs(HISTORY_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --- FUNGSI HELPER (Gabungan dan Penambahbaikan) ---

@st.cache_data(ttl=300)
def get_ollama_models_cached():
    """Mendapatkan senarai model yang tersedia dari Ollama dan mengcache hasilnya."""
    try:
        response = requests.get(f'{OLLAMA_BASE_URL}/api/tags', timeout=10)
        response.raise_for_status()
        models_data = response.json().get('models', [])
        if not models_data:
            return []
        return sorted([model['name'] for model in models_data])
    except requests.exceptions.Timeout:
        st.error(f"Gagal mendapatkan senarai model: Permintaan ke Ollama tamat masa.")
        return []
    except requests.exceptions.RequestException:
        return []
    except KeyError:
        st.error("Format respons senarai model tidak dijangka dari Ollama.")
        return []

def query_ollama(prompt, chat_history, selected_model):
    """Menghantar pertanyaan ke Ollama dan mengembalikan respons serta masa penjanaan."""
    messages_for_api = [{"role": msg["role"], "content": msg["content"]} for msg in chat_history]
    # Jika prompt bukan sebahagian daripada mesej terakhir dalam chat_history, tambahkannya
    if not messages_for_api or messages_for_api[-1]["content"] != prompt or messages_for_api[-1]["role"] != "user":
         messages_for_api.append({"role": "user", "content": prompt})

    start_time = time.time()
    try:
        # Menggunakan endpoint /api/chat yang lebih sesuai untuk perbualan
        payload = {'model': selected_model, 'messages': messages_for_api, 'stream': False}
        response = requests.post(f'{OLLAMA_BASE_URL}/api/chat', json=payload, timeout=600)
        response.raise_for_status()
        
        end_time = time.time()
        processing_time = end_time - start_time
        full_response_data = response.json()
        assistant_reply = full_response_data.get('message', {}).get('content', "Maaf, saya tidak dapat respons yang betul.")
        return assistant_reply, processing_time

    except requests.exceptions.Timeout:
        end_time = time.time(); processing_time = end_time - start_time
        st.error(f"Gagal mendapatkan respons: Permintaan ke Ollama tamat masa selepas {processing_time:.2f}s.")
        return "Maaf, permintaan tamat masa.", processing_time
    except requests.exceptions.RequestException as e:
        end_time = time.time(); processing_time = end_time - start_time
        st.error(f"Masalah menyambung ke Ollama: {e} (selepas {processing_time:.2f}s)")
        return "Maaf, berlaku masalah semasa menghubungi Ollama.", processing_time
    except KeyError:
        end_time = time.time(); processing_time = end_time - start_time
        st.error(f"Format respons tidak dijangka dari Ollama (selepas {processing_time:.2f}s).")
        return "Maaf, format respons dari Ollama tidak seperti yang dijangkakan.", processing_time

def save_chat_session(session_id, history):
    filepath = os.path.join(HISTORY_DIR, f"{session_id}.json")
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(history, f, indent=2)
    except IOError as e:
        st.error(f"Gagal menyimpan sesi sembang '{session_id}': {e}")

def load_chat_session(session_id):
    filepath = os.path.join(HISTORY_DIR, f"{session_id}.json")
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except (json.JSONDecodeError, IOError) as e:
        st.error(f"Gagal memuatkan atau membaca sesi sembang '{session_id}': {e}")
        return []

def load_all_session_ids():
    try:
        files = [f.replace(".json", "") for f in os.listdir(HISTORY_DIR) if f.endswith(".json")]
        def sort_key(filename):
            try:
                parts = filename.split('_')
                if len(parts) >= 2:
                    return datetime.strptime(f"{parts[0]}_{parts[1]}", "%Y%m%d_%H%M%S")
            except (ValueError, IndexError): pass
            return datetime.min # Fallback untuk nama fail yang tidak mengikut format tarikh
        return sorted(files, key=sort_key, reverse=True)
    except OSError as e:
        st.error(f"Gagal membaca direktori sesi: {e}")
        return []

def delete_chat_session_file(session_id):
    filepath = os.path.join(HISTORY_DIR, f"{session_id}.json")
    try:
        if os.path.exists(filepath):
            os.remove(filepath)
            st.success(f"Sesi sembang '{session_id}' berjaya dipadam.")
            return True
        else:
            st.warning(f"Fail sesi sembang '{session_id}' tidak ditemui untuk dipadam.")
            return False
    except OSError as e:
        st.error(f"Gagal memadam sesi sembang '{session_id}': {e}")
        return False

def delete_all_chat_sessions():
    deleted_count = 0; errors = []
    try:
        for filename in os.listdir(HISTORY_DIR):
            if filename.endswith(".json"):
                filepath = os.path.join(HISTORY_DIR, filename)
                try: os.remove(filepath); deleted_count += 1
                except OSError as e: errors.append(f"Gagal memadam {filename}: {e}")
        if errors:
            for error in errors: st.error(error)
        if deleted_count > 0: st.success(f"{deleted_count} sesi sembang berjaya dipadam.")
        else: st.info("Tiada sesi sembang ditemui untuk dipadam.")
        return True
    except OSError as e:
        st.error(f"Gagal mengakses direktori sesi: {e}")
        return False

# --- FUNGSI EKSTRAKSI TEKS DARI FAIL (dari chatbot2) ---
def extract_text_from_file(uploaded_file_obj):
    extracted_text = ""
    filename = uploaded_file_obj.name
    file_bytes = uploaded_file_obj.getvalue() # Dapatkan bytes terus

    try:
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
            image = Image.open(uploaded_file_obj) # PIL boleh buka objek fail secara terus
            extracted_text = pytesseract.image_to_string(image)
            if not extracted_text.strip():
                 st.info(f"Tiada teks dapat diekstrak dari imej '{filename}' menggunakan OCR.")
        elif filename.lower().endswith(".txt"):
            extracted_text = file_bytes.decode('utf-8', errors='ignore')
        elif filename.lower().endswith(".docx"):
            # Simpan sementara untuk dibaca oleh python-docx
            temp_docx_path = os.path.join(UPLOAD_DIR, f"temp_{filename}")
            with open(temp_docx_path, "wb") as f:
                f.write(file_bytes)
            doc = Document(temp_docx_path)
            extracted_text = "\n".join([para.text for para in doc.paragraphs])
            os.remove(temp_docx_path) # Padam fail sementara
        elif filename.lower().endswith(".pdf"):
            # PyMuPDF boleh buka bytes terus
            doc = fitz.open(stream=file_bytes, filetype="pdf")
            for page in doc:
                extracted_text += page.get_text()
            doc.close()
        else:
            st.warning(f"Jenis fail '{filename}' tidak disokong untuk ekstraksi teks.")
            return None

        return extracted_text.strip()

    except Exception as e:
        st.error(f"Ralat semasa memproses fail '{filename}': {e}")
        # Cuba padam fail sementara jika ada dan gagal
        if 'temp_docx_path' in locals() and os.path.exists(temp_docx_path):
            try: os.remove(temp_docx_path)
            except: pass
        return None

# --- FUNGSI EKSPORT (Gabungan dengan logo/watermark dari chatbot2) ---
def format_conversation_text(chat_history, include_user=True, include_assistant=True):
    lines = []
    for msg in chat_history:
        if (msg["role"] == "user" and include_user) or \
           (msg["role"] == "assistant" and include_assistant):
            lines.append(f"{msg['role'].capitalize()}: {msg['content'].strip()}")
    return "\n\n".join(lines)

def save_to_word(text_content, filename='output.docx', logo_path=LOGO_PATH, watermark_text=WATERMARK_TEXT):
    doc = Document()
    if logo_path and os.path.exists(logo_path):
        try:
            paragraph = doc.add_paragraph()
            run = paragraph.add_run()
            run.add_picture(logo_path, width=DocxInches(2.0)) # Saiz logo boleh laras
            paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
            doc.add_paragraph() # Baris kosong selepas logo
        except Exception as e:
            st.warning(f"Gagal menambah logo pada Word: {e}. Pastikan fail imej sah.")

    if watermark_text:
        watermark_para = doc.add_paragraph()
        run = watermark_para.add_run(watermark_text)
        font = run.font
        font.size = DocxPt(36) # Saiz tera air
        font.color.rgb = DocxRGBColor(192, 192, 192)  # Kelabu cair
        font.bold = True
        watermark_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        doc.add_paragraph()

    for para_block in text_content.split("\n\n"):
        doc.add_paragraph(para_block.strip())
    try: doc.save(filename); return True
    except IOError as e: st.error(f"Gagal menyimpan ke Word: {e}"); return False

def save_to_pdf(text_content, filename='output.pdf', logo_path=LOGO_PATH, watermark_text=WATERMARK_TEXT):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    if logo_path and os.path.exists(logo_path):
        try:
            # Letak logo di tengah atas
            img_width = 30 # mm
            page_width = pdf.w - 2 * pdf.l_margin
            x_logo = (page_width - img_width) / 2 + pdf.l_margin
            pdf.image(logo_path, x=x_logo, y=10, w=img_width)
            pdf.ln(25) # Ruang selepas logo
        except Exception as e:
            st.warning(f"Gagal menambah logo pada PDF: {e}. Pastikan fail imej sah dan format disokong oleh FPDF (PNG, JPG, GIF).")

    if watermark_text:
        pdf.set_font("Arial", 'B', 30)
        pdf.set_text_color(220, 220, 220) # Kelabu sangat cair
        # Letak tera air di tengah halaman (secara kasar)
        text_w = pdf.get_string_width(watermark_text)
        pdf.set_xy((pdf.w - text_w) / 2, pdf.h / 2 - 15) # Laraskan Y jika perlu
        pdf.cell(text_w, 10, watermark_text, 0, 0, 'C')
        pdf.set_text_color(0, 0, 0) # Reset warna teks
        pdf.set_xy(pdf.l_margin, pdf.get_y() + 15 if not (logo_path and os.path.exists(logo_path)) else 35) # Reset kedudukan Y

    pdf.set_font("Arial", size=12)
    for para_block in text_content.split("\n\n"):
        for line in para_block.strip().split('\n'):
            pdf.multi_cell(0, 10, line)
        pdf.ln(5) # Ruang antara perenggan
    try: pdf.output(filename); return True
    except Exception as e: st.error(f"Gagal menyimpan ke PDF: {e}"); return False

def save_to_txt(text_content, filename='output.txt'):
    try:
        with open(filename, "w", encoding="utf-8") as f: f.write(text_content)
        return True
    except IOError as e: st.error(f"Gagal menyimpan ke Teks: {e}"); return False

def save_to_excel(chat_history, filename='chat_output.xlsx'):
    # Eksport semua mesej (user dan assistant) seperti dalam chatbot1
    data = [[msg["role"].capitalize(), msg["content"]] for msg in chat_history]
    df = pd.DataFrame(data, columns=["Role", "Message"])
    try: df.to_excel(filename, index=False, engine='openpyxl'); return True
    except Exception as e: st.error(f"Gagal menyimpan ke Excel: {e}"); return False

def save_to_pptx(chat_history, filename='chat_output.pptx', logo_path=LOGO_PATH):
    prs = Presentation()
    # Gunakan susun atur yang lebih fleksibel, contohnya 'Blank' atau 'Title and Content'
    # slide_layout = prs.slide_layouts[5] # Title Only
    slide_layout = prs.slide_layouts[6] # Blank, lebih fleksibel

    for msg in chat_history:
        slide = prs.slides.add_slide(slide_layout)

        if logo_path and os.path.exists(logo_path):
            try:
                # Logo di penjuru atas kiri
                pic = slide.shapes.add_picture(logo_path, PptxInches(0.2), PptxInches(0.2), height=PptxInches(0.75))
            except Exception as e:
                 st.warning(f"Gagal menambah logo pada PowerPoint: {e}. Pastikan fail imej sah.")

        # Kotak teks untuk peranan dan kandungan
        # Laraskan kedudukan dan saiz berdasarkan kehadiran logo
        left = PptxInches(0.5)
        top = PptxInches(1.0) if logo_path and os.path.exists(logo_path) else PptxInches(0.5)
        width = PptxInches(9.0)
        height = PptxInches(5.5)

        textbox = slide.shapes.add_textbox(left, top, width, height)
        tf = textbox.text_frame
        tf.word_wrap = True

        p_role = tf.add_paragraph()
        p_role.text = f"{msg['role'].capitalize()}:"
        p_role.font.bold = True
        p_role.font.size = PptxPt(18)
        p_role.font.name = 'Arial'

        p_content = tf.add_paragraph()
        p_content.text = msg['content']
        p_content.font.size = PptxPt(16)
        p_content.font.name = 'Arial'
        p_content.level = 1 # Inden sedikit untuk kandungan

    try: prs.save(filename); return True
    except IOError as e: st.error(f"Gagal menyimpan ke PowerPoint: {e}"); return False

# --- PENGURUSAN STATE STREAMLIT ---
def initialize_session_state(available_models_list):
    if "session_id" not in st.session_state:
        st.session_state.session_id = "new" # "new" untuk sesi baru, atau ID sesi
        st.session_state.chat_history = []
        st.session_state.current_filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    if "selected_ollama_model" not in st.session_state:
        if available_models_list and DEFAULT_OLLAMA_MODEL in available_models_list:
            st.session_state.selected_ollama_model = DEFAULT_OLLAMA_MODEL
        elif available_models_list:
            st.session_state.selected_ollama_model = available_models_list[0]
        else:
            st.session_state.selected_ollama_model = DEFAULT_OLLAMA_MODEL # Fallback jika tiada model atau model lalai tiada

    if "show_confirm_delete_all_button" not in st.session_state:
        st.session_state.show_confirm_delete_all_button = False
    
    if "chat_page_num" not in st.session_state: # Untuk paginasi sembang
        st.session_state.chat_page_num = 1


# --- KOMPONEN UI ---
def display_sidebar(available_models_list):
    st.sidebar.header("⚙️ Tetapan")
    if available_models_list:
        try:
            current_model_index = available_models_list.index(st.session_state.selected_ollama_model)
        except ValueError:
            current_model_index = 0
            if available_models_list: st.session_state.selected_ollama_model = available_models_list[0]
            else: st.session_state.selected_ollama_model = DEFAULT_OLLAMA_MODEL

        selected_model_ui = st.sidebar.selectbox(
            "Pilih Model AI:", options=available_models_list, index=current_model_index, key="model_selector_widget"
        )
        if selected_model_ui != st.session_state.selected_ollama_model:
            st.session_state.selected_ollama_model = selected_model_ui
            # st.rerun() # Tidak perlu rerun di sini, akan dikemas kini secara automatik
    else:
        st.sidebar.warning("Tiada model AI ditemui dari Ollama.")
        if "selected_ollama_model" not in st.session_state: # Pastikan ada nilai walaupun tiada model
             st.session_state.selected_ollama_model = DEFAULT_OLLAMA_MODEL

    st.sidebar.divider()
    st.sidebar.header("🕘 Sesi Sembang")
    session_ids = load_all_session_ids()
    # Pastikan "new" (atau apa sahaja yang mewakili sesi baru) ada dalam session_ids jika itu ID semasa
    # Ini penting untuk selectbox mencari index yang betul
    current_session_for_select = st.session_state.session_id
    
    options = ["➕ Sembang Baru"] + session_ids
    
    try:
        # Jika sesi semasa ialah "new", index adalah 0 ("➕ Sembang Baru")
        # Jika tidak, cari index sesi semasa dalam senarai options
        current_session_index = options.index(current_session_for_select) if current_session_for_select != "new" else 0
    except ValueError: # Jika session_id semasa tidak ditemui (cth: fail dipadam secara manual)
        current_session_index = 0 # Default ke "➕ Sembang Baru"
        st.session_state.session_id = "new"
        st.session_state.chat_history = []
        st.session_state.current_filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")


    selected_session_id_ui = st.sidebar.selectbox(
        "Pilih atau mulakan sesi sembang:", options, index=current_session_index, key="session_selector_widget"
    )

    st.sidebar.divider()
    st.sidebar.subheader("🗑️ Urus Sesi")
    can_delete_current = st.session_state.session_id != "new" and st.session_state.session_id in session_ids
    if can_delete_current:
        if st.sidebar.button(f"Padam Sesi: {st.session_state.session_id}", key="delete_current_btn", type="secondary"):
            if delete_chat_session_file(st.session_state.session_id):
                st.session_state.session_id = "new"; st.session_state.chat_history = []
                st.session_state.current_filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")
                st.session_state.show_confirm_delete_all_button = False
                st.session_state.chat_page_num = 1 # Reset paginasi
                st.rerun()

    if session_ids:
        if not st.session_state.show_confirm_delete_all_button:
            if st.sidebar.button("Padam Semua Sesi", key="ask_delete_all_btn"):
                st.session_state.show_confirm_delete_all_button = True
                st.rerun()
        
        if st.session_state.show_confirm_delete_all_button:
            st.sidebar.warning("ANDA PASTI MAHU MEMADAM SEMUA SESI? TINDAKAN INI TIDAK BOLEH DIBATALKAN.")
            col1, col2 = st.sidebar.columns(2)
            with col1:
                if st.button("YA, PADAM SEMUA", key="confirm_delete_all_btn", type="primary"):
                    if delete_all_chat_sessions():
                        st.session_state.session_id = "new"; st.session_state.chat_history = []
                        st.session_state.current_filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")
                        st.session_state.show_confirm_delete_all_button = False
                        st.session_state.chat_page_num = 1 # Reset paginasi
                        st.rerun()
            with col2:
                if st.button("TIDAK, BATAL", key="cancel_delete_all_btn"):
                    st.session_state.show_confirm_delete_all_button = False
                    st.rerun()
    else:
        st.session_state.show_confirm_delete_all_button = False
    
    st.sidebar.info(
        f"""
        **Nota:**
        Pastikan servis Ollama anda berjalan.
        Model yang tersedia akan disenaraikan di atas.
        URL Ollama: `{OLLAMA_BASE_URL}`
        Logo: `{LOGO_PATH if os.path.exists(LOGO_PATH) else "Tidak ditemui"}`
        Tera Air: `{WATERMARK_TEXT}`
        """
    )
    return selected_session_id_ui

def handle_session_logic(selected_session_id_from_ui):
    # Logik ini dijalankan apabila pilihan sesi di sidebar berubah
    if selected_session_id_from_ui == "➕ Sembang Baru":
        if st.session_state.session_id != "new": # Jika bertukar DARI sesi sedia ada KE baru
            st.session_state.session_id = "new"
            st.session_state.chat_history = []
            st.session_state.current_filename_prefix = datetime.now().strftime("%Y%m%d_%H%M%S")
            st.session_state.chat_page_num = 1
            # st.rerun() # Rerun akan berlaku secara semula jadi jika widget berubah
    elif st.session_state.session_id != selected_session_id_from_ui: # Jika bertukar KE sesi sedia ada YANG LAIN
        st.session_state.chat_history = load_chat_session(selected_session_id_from_ui)
        st.session_state.session_id = selected_session_id_from_ui
        st.session_state.current_filename_prefix = selected_session_id_from_ui # Gunakan ID sesi sebagai prefix
        st.session_state.chat_page_num = 1
        # st.rerun()

def display_chat_messages_paginated():
    st.subheader("📜 Perbualan")
    if not st.session_state.chat_history:
        st.info("Mulakan perbualan dengan menaip di bawah atau muat naik fail.")
        return

    page_size = 10 # Bilangan mesej setiap halaman
    total_messages = len(st.session_state.chat_history)
    
    # Kira max_page dengan betul, pastikan sekurang-kurangnya 1 halaman
    max_page = (total_messages + page_size - 1) // page_size if total_messages > 0 else 1
    
    # Pastikan chat_page_num berada dalam lingkungan yang sah
    if st.session_state.chat_page_num > max_page:
        st.session_state.chat_page_num = max_page
    if st.session_state.chat_page_num < 1:
        st.session_state.chat_page_num = 1

    # Hanya tunjukkan slider jika lebih dari satu halaman
    if max_page > 1:
        page_num_ui = st.slider(
            "Halaman Sembang:", 
            min_value=1, 
            max_value=max_page, 
            value=st.session_state.chat_page_num, 
            key="chat_page_slider"
        )
        if page_num_ui != st.session_state.chat_page_num:
            st.session_state.chat_page_num = page_num_ui
            # st.rerun() # Tidak perlu rerun, widget akan trigger
    else:
        st.session_state.chat_page_num = 1 # Jika hanya satu halaman, pastikan ia adalah halaman 1

    # Kira mesej untuk dipaparkan berdasarkan halaman semasa
    # Papar mesej terbaru dahulu (songsangkan senarai untuk paparan, tetapi simpan dalam susunan asal)
    reversed_history = st.session_state.chat_history[::-1]
    start_index = (st.session_state.chat_page_num - 1) * page_size
    end_index = start_index + page_size
    
    # Papar mesej dalam susunan kronologi untuk halaman semasa
    messages_to_display = reversed_history[start_index:end_index][::-1] 

    for msg in messages_to_display:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg["role"] == "assistant" and "time_taken" in msg and msg["time_taken"] is not None:
                st.caption(f"Dijana dalam {msg['time_taken']:.2f} saat")

def display_export_options():
    st.divider()
    st.subheader("📤 Eksport Sembang")
    if not st.session_state.chat_history:
        st.info("Tiada perbualan untuk dieksport.")
        return

    col_export1, col_export2 = st.columns(2)
    with col_export1:
        export_content_choice = st.radio(
            "Kandungan untuk dieksport (Teks, Word, PDF):",
            ["Pembantu Sahaja", "Pengguna Sahaja", "Keseluruhan Perbualan"],
            index=2, key="export_content_radio"
        )
    with col_export2:
        export_format_choice = st.selectbox("Format eksport:", [
            "Pilih format", "Word (.docx)", "Teks (.txt)", "PDF (.pdf)",
            "Excel (.xlsx)", "PowerPoint (.pptx)"
        ], key="export_format_select")

    custom_filename_prefix_ui = st.text_input(
        "Nama fail awalan (tanpa sambungan):",
        st.session_state.current_filename_prefix,
        key="filename_prefix_input"
    )
    if custom_filename_prefix_ui != st.session_state.current_filename_prefix:
        st.session_state.current_filename_prefix = custom_filename_prefix_ui

    if st.button("Eksport", key="export_main_button"):
        if export_format_choice == "Pilih format":
            st.warning("Sila pilih format eksport yang sah."); return
        
        filename_base = st.session_state.current_filename_prefix
        include_user = "Pengguna" in export_content_choice or "Keseluruhan" in export_content_choice
        include_assistant = "Pembantu" in export_content_choice or "Keseluruhan" in export_content_choice
        
        # Untuk Excel dan PPTX, kita mungkin mahu keseluruhan sejarah tanpa mengira pilihan radio
        # atau kita boleh tapis berdasarkan pilihan juga. Buat masa ini, Excel dan PPTX akan ambil keseluruhan.
        # Jika mahu tapis, perlu ubah data yang dihantar ke save_to_excel/pptx.
        
        text_for_common_formats = format_conversation_text(st.session_state.chat_history, include_user, include_assistant)
        
        success, exported_filename = False, ""
        actions = {
            "Word (.docx)": (save_to_word, text_for_common_formats, f"{filename_base}.docx"),
            "Teks (.txt)": (save_to_txt, text_for_common_formats, f"{filename_base}.txt"),
            "PDF (.pdf)": (save_to_pdf, text_for_common_formats, f"{filename_base}.pdf"),
            "Excel (.xlsx)": (save_to_excel, st.session_state.chat_history, f"{filename_base}.xlsx"), # Hantar keseluruhan sejarah
            "PowerPoint (.pptx)": (save_to_pptx, st.session_state.chat_history, f"{filename_base}.pptx") # Hantar keseluruhan sejarah
        }
        if export_format_choice in actions:
            func, data, fname = actions[export_format_choice]
            success = func(data, fname) # Fungsi save_to_ akan guna LOGO_PATH dan WATERMARK_TEXT secara lalai
            exported_filename = fname
        
        if success and exported_filename:
            st.success(f"Fail disimpan: {exported_filename}")
            try:
                with open(exported_filename, "rb") as f_download:
                    st.download_button(
                        "📥 Muat Turun Fail", data=f_download, file_name=exported_filename, 
                        key=f"download_btn_{exported_filename.replace('.', '_')}_{time.time()}" # Tambah timestamp untuk kekunci unik
                    )
            except FileNotFoundError: st.error(f"Gagal mencari fail {exported_filename} untuk dimuat turun.")
            except Exception as e: st.error(f"Ralat semasa menyediakan muat turun: {e}")

# --- FUNGSI UTAMA APLIKASI ---
def main():
    st.set_page_config(page_title="DFK Stembot Gabungan", layout="wide", initial_sidebar_state="expanded", page_icon="🤖")
    st.title("🤖 DFK Stembot Gabungan")

    available_ollama_models = get_ollama_models_cached()
    if not available_ollama_models:
        st.error("Tidak dapat memuatkan senarai model dari Ollama. Pastikan Ollama berjalan dan mempunyai model. Aplikasi mungkin tidak berfungsi dengan betul.")
    
    initialize_session_state(available_ollama_models)

    st.caption(f"Model semasa: **{st.session_state.selected_ollama_model}** | Menyambung ke: {OLLAMA_BASE_URL}")
    
    selected_session_id_from_ui = display_sidebar(available_ollama_models)
    handle_session_logic(selected_session_id_from_ui)
    
    # --- Bahagian Muat Naik Fail (dari chatbot2) ---
    st.sidebar.divider()
    st.sidebar.header("📎 Muat Naik Fail")
    uploaded_file = st.sidebar.file_uploader(
        "Muat naik imej, PDF, DOCX, atau TXT untuk diproses:", 
        type=['png', 'jpg', 'jpeg', 'gif', 'pdf', 'txt', 'docx'],
        key="file_uploader"
    )

    if uploaded_file is not None:
        with st.spinner(f"Memproses fail '{uploaded_file.name}'..."):
            extracted_text = extract_text_from_file(uploaded_file)
        
        if extracted_text:
            st.info(f"Teks diekstrak dari '{uploaded_file.name}'. Anda boleh bertanya mengenainya atau ia akan disertakan dalam konteks seterusnya.")
            # Tambah mesej pengguna dengan kandungan fail
            file_content_message = f"Kandungan dari fail '{uploaded_file.name}':\n\n{extracted_text}"
            st.session_state.chat_history.append({"role": "user", "content": file_content_message})
            
            # Dapatkan respons dari LLM mengenai kandungan fail
            with st.spinner(f"{st.session_state.selected_ollama_model.split(':')[0].capitalize()} sedang memproses kandungan fail..."):
                assistant_response, gen_time = query_ollama(
                    file_content_message, # Hantar mesej kandungan fail sebagai prompt semasa
                    st.session_state.chat_history[:-1], # Hantar sejarah sebelum mesej fail ini
                    st.session_state.selected_ollama_model
                )
            st.session_state.chat_history.append({
                "role": "assistant", 
                "content": assistant_response,
                "time_taken": gen_time
            })
            # Simpan sesi selepas pemprosesan fail
            if st.session_state.session_id == "new":
                new_id = st.session_state.current_filename_prefix # Guna prefix semasa
                # Pastikan ID unik jika "new"
                all_ids = load_all_session_ids()
                counter = 1
                temp_id = new_id
                while temp_id in all_ids:
                    temp_id = f"{st.session_state.current_filename_prefix}_{counter}"
                    counter +=1
                new_id = temp_id
                save_chat_session(new_id, st.session_state.chat_history)
                st.session_state.session_id = new_id
                st.session_state.current_filename_prefix = new_id
            else:
                save_chat_session(st.session_state.session_id, st.session_state.chat_history)
            st.rerun() # Untuk memaparkan mesej baru dari fail
        elif extracted_text is not None: # Bermakna extract_text_from_file mengembalikan string kosong (tiada teks)
            st.warning(f"Tiada teks dapat diekstrak dari fail '{uploaded_file.name}'.")
        # Jika extracted_text adalah None, ralat telah dipaparkan dalam extract_text_from_file

        # Kosongkan uploader selepas pemprosesan untuk mengelakkan pemprosesan semula
        # Ini adalah helah biasa, mungkin perlu disesuaikan jika st.experimental_rerun() digunakan secara berbeza
        st.session_state.file_uploader = None 
        # st.experimental_rerun() # Atau st.rerun() jika versi Streamlit > 1.17.0


    display_chat_messages_paginated() # Guna fungsi paginasi

    friendly_model_name = st.session_state.selected_ollama_model.split(':')[0].capitalize()
    user_input = st.chat_input(f"Taip mesej anda kepada {friendly_model_name}...")

    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        
        with st.spinner(f"{friendly_model_name} sedang menaip..."):
            assistant_response_text, generation_time = query_ollama(
                user_input, 
                st.session_state.chat_history, # Hantar keseluruhan sejarah termasuk input pengguna terkini
                st.session_state.selected_ollama_model
            )
        
        st.session_state.chat_history.append({
            "role": "assistant", 
            "content": assistant_response_text,
            "time_taken": generation_time
        })

        if st.session_state.session_id == "new":
            new_session_actual_id = st.session_state.current_filename_prefix
            all_ids = load_all_session_ids()
            counter = 1
            temp_id = new_session_actual_id
            while temp_id in all_ids: # Pastikan ID unik
                temp_id = f"{st.session_state.current_filename_prefix}_{counter}"
                counter +=1
            new_session_actual_id = temp_id
            
            save_chat_session(new_session_actual_id, st.session_state.chat_history)
            st.session_state.session_id = new_session_actual_id 
            st.session_state.current_filename_prefix = new_session_actual_id # Kemas kini prefix juga
        else:
            save_chat_session(st.session_state.session_id, st.session_state.chat_history)
        
        # Reset ke halaman terakhir selepas mesej baru untuk melihatnya
        total_messages = len(st.session_state.chat_history)
        page_size = 10
        st.session_state.chat_page_num = (total_messages + page_size - 1) // page_size if total_messages > 0 else 1
        st.rerun()

    display_export_options()


if __name__ == "__main__":
    # Cadangan untuk fail requirements.txt:
    #
    # streamlit>=1.17.0
    # requests
    # python-docx
    # fpdf2
    # pandas
    # openpyxl
    # python-pptx
    # Pillow
    # pytesseract
    # PyMuPDF
    #
    # Pasang menggunakan: pip install -r requirements.txt
    # Juga, pastikan Tesseract OCR dipasang pada sistem anda.
    main()